# TicTacToeButGood
Tic Tac Toe but it's actually good NEW AND IMPROVED!!

FEATURES!
- Computer impossible X
- Computer impossible (?) O
- If you are unsure of what you want to play, there is the labelled "Play Random Move" button
- Made a Mistake? You can copy and paste the array of numbers down below "Save", Refresh the page (or click "Reset"), Click "flip switch", play the indicated numbers in sequential order, and save and load feature!
- Don't like the size of the board? You can change it with the slider!!

New and improved version (or NAI version) is finished in 1/25/2023, and it is a WHOLE LOT BETTER than the scratch version with a lot more features than the to-death limited scratch version released in 10 Dec 2023!

(NAI version will be labeled as 2.0 from now on)
2.1: (10/16/2024)

- Made the O Computer actually impossible (if you can beat it, tell me)
- Can now close computer mode
- Customizable Computer AI
