let threat = function(attacker){
    if (game.Position[4] === attacker) {
        for (let i = 0; i < 9; i++){
            if (game.Position[0 + i] === attacker && game.Position[8 - i] === 0) 
                return 8 - i;
        }
    }else if (game.Position[4] == 0){
        for (let i = 0; i < 4; i++){
            if (game.Position[0 + i] === attacker && game.Position[8 - i] === attacker) 
                return 4;
        }
    }
    if (game.Position[0] === attacker) {
        if (game.Position[2] === attacker && game.Position[1] === 0)
            return 1
        else if (game.Position[1] === attacker && game.Position[2] === 0)
            return 2
        else if (game.Position[3] === attacker && game.Position[6] === 0)
            return 6
        else if (game.Position[6] === attacker && game.Position[3] === 0)
            return 3
        else if (game.Position[8] === attacker && game.Position[4] === 0)
            return 4
    }
    if (game.Position[8] === attacker){
        if (game.Position[2] === attacker && game.Position[5] === 0)
            return 5
        else if (game.Position[5] === attacker && game.Position[2] === 0)
            return 2
        else if (game.Position[6] === attacker && game.Position[7] === 0)
            return 7
        else if (game.Position[7] === attacker && game.Position[6] === 0)
            return 6
    }
    if (game.Position[2] === attacker) {
        if (game.Position[1] === attacker && game.Position[0] === 0)
            return 0
        else if (game.Position[5] === attacker && game.Position[8] === 0)
            return 8
        else if (game.Position[6] === attacker && game.Position[4] === 0)
            return 4
    }
    if (game.Position[6] === attacker){
        if (game.Position[3] === attacker && game.Position[0] === 0)
            return 0
        else if (game.Position[7] === attacker && game.Position[8] == 0)
            return 8
        else if (game.Position[8] === attacker && game.Position[7] == 0)
            return 7
    }
    return null
}
ComputerFunction = () => {
    // if it is the computer's turn
    if (ComputerPlay == Gamestate){
        // if the computer has a threat
        if (typeof threat(ComputerPlay) === "number"){ 
            // play the computer threat
            play(threat(ComputerPlay)); return
        }
        // if the player has a threat
        if (typeof threat(3-ComputerPlay) === "number") {
            // play the player threat
            play(threat(3-ComputerPlay)); return
        }
        // Computer is X
        if (ComputerPlay == 1){
            switch (game.Movelist.join()) {
                case "":
                    play(2)
                    return;
                case "2,0":
                case "2,4":
                case "2,8":
                    play(6)
                    return;
                case "2,1":
                case "2,3":
                case "2,7":
                case "2,6":
                    play(8)
                    return;
                case "2,5":
                    play(1)
                    return;
                case "2,1,8,5":
                case "2,3,8,5":
                case "2,7,8,5":
                case "2,5,1,0":
                    play(4)
                    return;
                case "2,6,8,5":
                    play(0)
                    return;
                default:
                    console.log("Computer X Played Randomly")
                    PlayR()
                    return;
            }
            // computer is O
        } else if (ComputerPlay == 2){
            if (game.Movelist.length == 1 && game.Movelist[0] !== 4){
                play(4)
                return;
            }
            switch (game.Movelist.join()){
                case "4":
                case "1,4,6,3,5":
                case "6,4,1,3,5":
                case "1,4,7":
                case "7,4,1":
                case "5,4,6,7,1":
                case "6,4,5,7,1":
                case "3,4,5":
                case "5,4,3":
                    play(2)
                    return;
                case "4,2,6":
                case "0,4,7,3,5":
                case "7,4,0,3,5":
                    play(8)
                    return;
                case "0,4,8":
                case "2,4,6":
                case "6,4,2":
                case "8,4,0":
                case "0,4,7":
                case "1,4,6":
                case "1,4,8":
                case "2,4,7":
                case "7,4,0":
                case "6,4,1":
                case "8,4,1":
                case "7,4,2":
                    play(3)
                    return;
                case "0,4,5":
                case "5,4,0":
                case "2,4,3":
                case "3,4,2":
                case "3,4,8":
                case "8,4,3":
                case "5,4,6":
                case "6,4,5":
                    play(7)
                    return;
                case "8,4,3,7,1":
                case "3,4,8,7,1":
                    play(0)
                    return;
                default:
                    PlayR()
                    console.log("Computer O Played Randomly")
                    return;
            }
        }
    }
}